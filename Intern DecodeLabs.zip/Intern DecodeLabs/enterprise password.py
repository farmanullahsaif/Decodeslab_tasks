import random
import string
print("____Random Password Generator____")
length = int(input("Enter the length of password (min:4) "))
if length < 4:
     print("Password should atleast 4 characters long")
else:
     characters = string.ascii_letters + string.digits + string.punctuation
password = ""
for i in range(length):
          password += random.choice(characters)
print("\n Generated  ur secured password!!!")
print(password)