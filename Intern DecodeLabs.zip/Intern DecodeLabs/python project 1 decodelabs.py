#_____Python Project 1______
#_____TO-DO-List_________
tasks=[]
while True:
    print("\n____TO DO LIST____")
    print(" 1 : Add TAsk")
    print(" 2 : View Task")
    print(" 3 : Time to Exit ")
    choice = input("Enter ur choice")
    if choice == "1":
        task = input("Enter ur task ")
        tasks.append(task)
        print("YOUR TASk is Added successfully!")
    elif choice == "2":
        if len (tasks)== 0:
            print ("No task added")
        else:
            print("\nYour task is here ")
            for i in range(len(tasks)):
                print(f"{i+1}. {tasks[i]}")
    elif choice =="3":
                print('Thank u for using to do list ')
                print("Proggram ended")
                break
    else:
                print("Invalid choice!! kindly choose 1, 2 ,3 ")


