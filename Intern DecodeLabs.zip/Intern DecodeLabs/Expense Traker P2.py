#_____Python Project_______
#-----Expense Tacker-------
Total = 0
expense_number = 1
expenses=[]
while True:
 print(" 1 :Add expense")
 print(" 2 : View expense")
 print(" 3 : Exit")
 choose = input("Enter ur choice")
 if choose == "1":
     while True:
       print('Enter expense' ,expense_number)
       expense = int(input())
       expenses.append(expense)
       expense_number += 1
  
       Total = Total + expense
       print('Do u want to add more expense Y/N')
       choice = input()
       if choice == "N":
              break
 elif choose == "2":
      print("\n----- Expense List -----")

      for i in range(len(expenses)):
         print(f"Expense {i + 1}: Rs. {expenses[i]}")
 elif choose == '3':
      print("Total Expense ", Total)
      print("Thank you Sir!")
      break
